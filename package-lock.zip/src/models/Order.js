const mongoose = require('mongoose');
const ShippingCost = require('./ShippingCost');

const orderSchema = new mongoose.Schema({
  products: [{
    productId: {
      type: mongoose.Types.ObjectId,
      ref: 'Product',
    },
    packageId: {
      type: mongoose.Types.ObjectId,
      ref: 'Package'
    },
    price: {
      type: Number,
      required: true,
      min: [0, 'قیمت نمی‌تواند منفی باشد']
    },
    discount: {
      type: Number,
      required: true,
      min: [0, 'تخفیف نمی‌تواند منفی باشد'],
      max: [100, 'تخفیف نمی‌تواند بیشتر از 100 درصد باشد']
    },
    count: {
      type: Number,
      required: true,
      min: [1, 'تعداد باید حداقل 1 باشد']
    }
  }],
  submition: {
    type: String,
    required: [true, 'نحوه ارسال الزامی است'],
    enum: ["پست", "پیک"]
  },
  totalPrice: {
    type: Number,
    required: [true, 'قیمت کل الزامی است'],
    min: [0, 'قیمت کل نمی‌تواند منفی باشد']
  },
  totalWeight: {
    type: Number,
    default: 0,
    min: [0, 'وزن کل نمی‌تواند منفی باشد']
  },
  shippingCost: {
    type: Number,
    default: 0,
    min: [0, 'هزینه ارسال نمی‌تواند منفی باشد']
  },
  discount: {
    type: Number,
    default: 0,
    min: [0, 'تخفیف نمی‌تواند منفی باشد']
  },
  discountCode: {
    type: String,
    default: '',
    trim: true
  },
  status: {
    type: String,
    default: 'پرداخت نشده',
    enum: ['پرداخت نشده', 'در انتظار تایید', 'در حال آماده‌سازی', 'ارسال شد', 'تحویل داده‌شد', 'لغو شد']
  },
  paymentId: {
    type: String,
    default: '',
    trim: true
  },
  authority: {
    type: String,
    required: [true, 'شناسه پرداخت الزامی است'],
    trim: true
  },
  postVerify: {
    type: String,
    default: '',
    trim: true
  },
  userId: {
    type: mongoose.Types.ObjectId,
    ref: 'User',
    required: [true, 'شناسه کاربر الزامی است']
  },
  isFreeOrder: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Add indexes
orderSchema.index({ userId: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ createdAt: -1 });

// Add virtual for totalWeight calculation
orderSchema.virtual('calculatedTotalWeight').get(async function () {
  if (!this.populated('products.productId') || !this.populated('products.packageId')) {
    await this.populate('products.productId');
    await this.populate('products.packageId');
  }

  let totalWeight = 0;
  for (const item of this.products) {
    if (item.productId) {
      totalWeight += (item.productId.weight || 0) * item.count;
    } else if (item.packageId) {
      totalWeight += (item.packageId.totalWeight || 0) * item.count;
    }
  }
  return totalWeight;
});

// Add virtual for shipping cost calculation
orderSchema.virtual('calculatedShippingCost').get(async function () {
  // نوع ارسال را از this.submition بگیر
  const shippingType = this.submition || 'پست';
  const shippingCostDoc = await ShippingCost.findOne({ type: shippingType });
  if (shippingCostDoc) {
    return shippingCostDoc.cost + (shippingCostDoc.costPerKg * this.totalWeight / 1000);
  }
  return 0;
});

// Pre-save middleware to update totalWeight and shippingCost
orderSchema.pre('save', async function (next) {
  if (this.isModified('products')) {
    this.totalWeight = await this.calculatedTotalWeight;
    this.shippingCost = await this.calculatedShippingCost;
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema); 